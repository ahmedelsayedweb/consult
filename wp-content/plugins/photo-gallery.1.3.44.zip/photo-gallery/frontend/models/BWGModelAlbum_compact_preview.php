<?php
class BWGModelAlbum_compact_preview {
}
<?php
class BWGModelThumbnails {
}